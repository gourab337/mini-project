///////////////////////////////////////////////////////////////////////////////
//!
//! \file
//! \brief  Header file for CcPlugin
//!
///////////////////////////////////////////////////////////////////////////////
// Copyright (c) IndigoVision Limited.
///////////////////////////////////////////////////////////////////////////////

#ifndef CCPLUGIN_H
#define CCPLUGIN_H

#include "windows.h"
#include "wchar.h"

#define DLL_EXPORT __declspec(dllexport)

#ifdef __cplusplus

extern "C"
{
#endif

    //
    // TYPES DECLARATION
    //

    #define CCPM_DEFAULT 1

    //
    // Change flags bitmask
    //
    #define CCP_CHANGE_NAME 1
    #define CCP_CHANGE_ICON 2
    #define CCP_CHANGE_METHODS 4

    typedef enum
    {
        CcPluginSuccess = 0,
        CcPluginFailure
    }
    CCPLUGIN_STATUS;

    typedef struct
    {
        const wchar_t* menuText;
        unsigned       methodId;
        const wchar_t* methodString;
        unsigned       flags;
    }
    CCPLUGIN_METHOD;

    typedef struct
    {
        const wchar_t*          objectName;
        const wchar_t*          iconFileName;
        HINSTANCE               iconModule;
        unsigned                iconResource;
        const CCPLUGIN_METHOD*  methods;
        int                     numMethods;
    }
    CCPLUGIN_OBJECTDEF;

    typedef void ( *CCPLUGIN_ENUMOBJECTSFN )(
                        ULONG_PTR,
                        unsigned,
                        const CCPLUGIN_OBJECTDEF* 
                        );

    typedef void ( *CCPLUGIN_UPDATECALLBACKFN )(
                        ULONG_PTR context,
                        unsigned objectId,
                        unsigned changeFlags,
                        const CCPLUGIN_OBJECTDEF* objectDef
                        );

    //
    // OPTIONAL FUNCTIONS DECLARATION
    // These methods can be optionally implemented by CC Plugins
    //
    
    CCPLUGIN_STATUS DLL_EXPORT CcPluginConfigure( HWND parent );
    
    //
    // REQUIRED FUNCTIONS DECLARATION
    // All CC Plugins must implement these functions.
    //

    CCPLUGIN_STATUS DLL_EXPORT CcPluginInit( 
                                    HINSTANCE instance, 
                                    HWND mainWnd 
                                    );

    void DLL_EXPORT CcPluginCleanup();

    CCPLUGIN_STATUS DLL_EXPORT CcPluginGetName( 
                                    wchar_t* buffer, 
                                    size_t length 
                                    );

   CCPLUGIN_STATUS DLL_EXPORT CcPluginEnumObjects(
                                    CCPLUGIN_ENUMOBJECTSFN callback,
                                    ULONG_PTR context
                                    );

    CCPLUGIN_STATUS DLL_EXPORT CcPluginInvoke(
                                    unsigned userId,
                                    const wchar_t* userName,
                                    unsigned objectId,
                                    unsigned siteId,
                                    unsigned mapId,
                                    unsigned methodId,
                                    const wchar_t* methodString
                                    );

    CCPLUGIN_STATUS DLL_EXPORT CcPluginSetUpdateCallback(
                                    CCPLUGIN_UPDATECALLBACKFN callback,
                                    ULONG_PTR context
                                    );
#ifdef __cplusplus
}
#endif
#endif // CCPLUGIN_H